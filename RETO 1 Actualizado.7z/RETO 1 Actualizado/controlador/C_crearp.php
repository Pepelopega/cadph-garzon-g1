<?php

include_once 'modelo/crearp.php';

class CrearP{
    static public function CrearTP($nom){
        $Crear = new CrearPartida;
        $CodigoPartida = $Crear->CrearTablaP($nom);
 
        echo "codigo=".$CodigoPartida;
        return $CodigoPartida;
    }

    static public function InsertarTP($nom, $codigo){
        $Crear = new CrearPartida;
        $Crear->InsertarTablaP($nom, $codigo);
    }

    static public function InsertarLLP($Id, $codigo){
        $Crear = new CrearPartida;
        $Crear->InsertarLLaveF($Id, $codigo);
    }
    
}

?>