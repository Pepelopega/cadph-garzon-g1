<?php

require 'modelo/consultat.php';

class C_consultar{
    static public function Cconsulta($codigo){

        $Consultar = new ConsultarTabla;
        $respuesta =  $Consultar->ConsultarT($codigo);

        return $respuesta;
    }

    static public function ConsultarC($Id, $codigo){

        $Consultar = new ConsultarTabla;
        $ResultadoCartas =  $Consultar->ConsultarCartas($Id, $codigo);

        return $ResultadoCartas;
    }
}

?>