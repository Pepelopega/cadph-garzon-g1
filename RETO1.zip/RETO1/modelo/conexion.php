<?php
class Conexion
{
    private $con;

    // Abrir conexión con base de datos --- //
    public function abrir()
    {
        $this->con = new mysqli('localhost', 'root', '', 'reto');

    }

    // Cerrar conexión con base de datos --- //
    public function cerrar()
    {
        $this->con->close();
    }

    // Buscar partida(tabla) --- //
    public function BuscarT($sql)
    {
        $query = $this->con->query($sql);
        return $query;
    }

    // Administrar tablas --- //
    public function AdminT($sql)
    {
        $query = $this->con->query($sql);
    }

    // Consultar registros en tablas --- //
    public function Consulta($sql)
    {
        $query = $this->con->query($sql);

        // crear array e insertar registros en ella --- //
        $retorno = [];
        $i = 0;
        while($fila = $query->fetch_assoc()){
            $retorno[$i] = $fila;
            $i++;
        }

        return $retorno; // Array con el registro de la consulta ---//
    }
}

