<?php

include_once 'modelo/conexion.php';

class CrearPartida
{

    static public function CrearTablaP($nom)
    {
        // Abrir conexión con base de datos --- //
        $conexion = new Conexion();
        $conexion->abrir();

        // Generar número hexadecimal de 5 dígitos --- //
        $Hnumber = dechex(rand(100000, 900000));
        $tablename = strval($Hnumber); // Nombre de partida(tabla) --- //
        
        // Crear partida (tabla) --- //
        $sql = "CREATE TABLE P$tablename( JugadorId int(1) not null auto_increment primary key,
        Nombre varchar(100));";
        $conexion->AdminT($sql);

        // Registrar jugador 1 --- //
        $sql = "INSERT INTO P$tablename( JugadorId, Nombre) VALUES( NULL, 'Jugador $nom');";
        $conexion->AdminT($sql);

        // Crear tabla programadores --- //
        $sql = "CREATE TABLE programadores$tablename( Id int(1) not null auto_increment primary key,
        Nombre varchar(100));";
        $conexion->AdminT($sql);

        // Registrar programadores --- //
        $sql = "INSERT INTO programadores$tablename( Id, Nombre) VALUES( NULL, 'Pedro'),( NULL, 'Juan'),( NULL, 'Carlos'),( NULL, 'Juanita'),( NULL, 'Antonio'),( NULL, 'Carolina'),( NULL, 'Manuel');";
        $conexion->AdminT($sql);

        // Contar programadores --- //
        $sql = "SELECT Id FROM programadores$tablename;";
        $resultado = $conexion->Consulta($sql);
        $cantidad1 = count($resultado);

        $seleccion1 = rand(1, $cantidad1); // generar número al azar entre 1 y la cantidad de programadores --- //

        // Seleccionar programadores --- //
        $sql = "SELECT Nombre FROM programadores$tablename;";
        $resultado = $conexion->Consulta($sql); 
        $resultadoF1 = [];

        foreach ($resultado as $results) { // insertar programadores en array  --- //
            array_push($resultadoF1, $results['Nombre']);
        }
        $Psecreto = $resultadoF1[$seleccion1 - 1]; // Seleccionar programador al azar  --- //
   

        // Crear tabla modulos --- //
        $sql = "CREATE TABLE modulos$tablename( Id int(1) not null auto_increment primary key,
        Nombre varchar(100));";
        $conexion->AdminT($sql);

        // Registrar modulos --- //
        $sql = "INSERT INTO modulos$tablename( Id, Nombre) VALUES( NULL, 'Nomina'),( NULL, 'Facturacion'),( NULL, 'Recibos'),( NULL, 'Comprobante contable'),( NULL, 'Usuarios'),( NULL, 'Contabilidad');";
        $conexion->AdminT($sql);

        // Contar modulos --- //
        $sql = "SELECT Id FROM modulos$tablename;";
        $resultado = $conexion->Consulta($sql);
        $cantidad2 = count($resultado);

        $seleccion2 = rand(1, $cantidad2); // generar número al azar entre 1 y la cantidad de modulos--- //

        // Seleccionar modulos --- //
        $sql = "SELECT Nombre FROM modulos$tablename;";
        $resultado = $conexion->Consulta($sql);
        $resultadoF2 = [];

        foreach ($resultado as $results) { // insertar modulos en array  --- //
            array_push($resultadoF2, $results['Nombre']);
        }
        $Msecreto = $resultadoF2[$seleccion2 - 1]; // Seleccionar modulo al azar  --- //


        // Crear tabla errores --- //
        $sql = "CREATE TABLE errores$tablename( Id int(1) not null auto_increment primary key,
        Nombre varchar(100));";
        $conexion->AdminT($sql);

        // Registrar errores --- //
        $sql = "INSERT INTO errores$tablename( Id, Nombre) VALUES( NULL, '404'),( NULL, 'Stack overflow'),( NULL, 'Memory out of range'),( NULL, 'Null pointer'),( NULL, 'Syntax error'),( NULL, 'Encoding error');";
        $conexion->AdminT($sql);

        // Contar errores --- //
        $sql = "SELECT Id FROM errores$tablename;";
        $resultado = $conexion->Consulta($sql);
        $cantidad3 = count($resultado);

        $seleccion3 = rand(1, $cantidad3); // generar número al azar entre 1 y la cantidad de errores--- //

        // Seleccionar errores --- //
        $sql = "SELECT Nombre FROM errores$tablename;";
        $resultado = $conexion->Consulta($sql);
        $resultadoF3 = [];

        foreach ($resultado as $results) { // insertar errores en array  --- //
            array_push($resultadoF3, $results['Nombre']);
        }

        $Esecreto = $resultadoF3[$seleccion3 - 1]; // Seleccionar error al azar  --- //


        // Crear tabla secretos --- //
        $sql = "CREATE TABLE secretos$tablename( Id int(1) not null auto_increment primary key,
        Nombre varchar(100),
        Categoria varchar(100));";
        $conexion->AdminT($sql);

        // insertar secretos en tabla secretos --- //
        $sql = "INSERT INTO secretos$tablename( Id, Nombre, Categoria) VALUES( NULL, '$Psecreto', 'programador'),( NULL, '$Msecreto', 'modulo'),( NULL, '$Esecreto', 'error');";
        $conexion->AdminT($sql);

        // Eliminar secreto de tabla programadores --- //
        $sql = "DELETE FROM programadores$tablename WHERE programadores$tablename.Id = $seleccion1;";
        $conexion->AdminT($sql);

        // Eliminar secreto de tabla modulos --- //
        $sql = "DELETE FROM modulos$tablename WHERE modulos$tablename.Id = $seleccion2;";
        $conexion->AdminT($sql);

        // Eliminar secreto de tabla errores --- //
        $sql = "DELETE FROM errores$tablename WHERE errores$tablename.Id = $seleccion3;";
        $conexion->AdminT($sql);


        // Crear tabla para insertar las cartas de cada jugador --- //
        $sql = "CREATE TABLE cartas$tablename( IdCarta int(1) not null auto_increment primary key,
        NombreCarta varchar(100), CategoriaCarta varchar(100),
        IdJugador int(1));";   
        $conexion->AdminT($sql);

        // Crear tabla para insertar las cartas del Jugador1 --- //
        $sql = "CREATE TABLE JugadorN1$tablename( NCartas int(1) not null auto_increment primary key,
        NombreCarta varchar(100), CategoriaCarta varchar(100),
        IdJugador int(1));";  
        $conexion->AdminT($sql);

        // Crear tabla para insertar las cartas del Jugador2 --- //
        $sql = "CREATE TABLE JugadorN2$tablename( NCartas int(1) not null auto_increment primary key,
        NombreCarta varchar(100), CategoriaCarta varchar(100),
        IdJugador int(1));";   
        $conexion->AdminT($sql);

        // Crear tabla para insertar las cartas del Jugador3 --- //
        $sql = "CREATE TABLE JugadorN3$tablename( NCartas int(1) not null auto_increment primary key,
        NombreCarta varchar(100), CategoriaCarta varchar(100),
        IdJugador int(1));";   
        $conexion->AdminT($sql);

        // Crear tabla para insertar las cartas del Jugador4 --- //
        $sql = "CREATE TABLE JugadorN4$tablename( NCartas int(1) not null auto_increment primary key,
        NombreCarta varchar(100), CategoriaCarta varchar(100),
        IdJugador int(1));"; 
        $conexion->AdminT($sql);

        // Contadores de cartas restantes --- //
        $restanteP = 1;
        $restanteM = 1;
        $restanteE = 1; 

        // Array con cada categoria --- //
        $categorias = array(
            0 => "programadores",
            1 => "modulos",
            2 => "errores"
        );

        // Seleccionar programadores --- //
        $sql = "SELECT Nombre FROM programadores$tablename;";
        $resultado = $conexion->Consulta($sql);
        $resultadoF1 = [];

        foreach ($resultado as $results) { // Insertar programadores en array --- //
            array_push($resultadoF1, $results['Nombre']);
        }

        // Seleccionar modulos --- //
        $sql = "SELECT Nombre FROM modulos$tablename;";
        $resultado = $conexion->Consulta($sql);
        $resultadoF2 = [];

        foreach ($resultado as $results) { // Insertar modulos en array --- //
            array_push($resultadoF2, $results['Nombre']);
        }

        // Seleccionar errores --- //
        $sql = "SELECT Nombre FROM errores$tablename;";
        $resultado = $conexion->Consulta($sql);
        $resultadoF3 = [];

        foreach ($resultado as $results) { // Insertar errores en array --- //
            array_push($resultadoF3, $results['Nombre']);
        }


        // Generar 4 cartas 4 veces para cada jugador --- //
        for ($i = 1; $i <= 4; $i++) {
            for ($i2 = 4; $i2 > 0; $i2--) {

                // Eliminar categoria de array si su tabla no tiene registros--- //
                if ($restanteP == 0) {
                    unset($categorias[0]);
                }

                if ($restanteM == 0) {
                    unset($categorias[1]);
                }

                if ($restanteE == 0) {
                    unset($categorias[2]);
                }

                $clave_aleatoriaT = array_rand($categorias, 1); // Generar clave aleatoria--- //
                $Ccarta = $categorias[$clave_aleatoriaT]; // seleccionar categoria al azar --- //


                if ($categorias[$clave_aleatoriaT] == "programadores") {


                    $clave_aleatoria = array_rand($resultadoF1, 1); // Generar clave aleatoria--- //
                    $NombreC = $resultadoF1[$clave_aleatoria]; // seleccionar programador al azar --- //
                    
                    // Eliminar programador de tabla programadores --- //
                    $sql = "DELETE FROM programadores$tablename WHERE programadores$tablename.Nombre = '$NombreC';";
                    $conexion->AdminT($sql);

                    // Actualizar lista de programadores --- //
                    $sql = "SELECT Nombre FROM programadores$tablename;";
                    $resultado = $conexion->Consulta($sql);
                    $resultadoF1 = [];

                    foreach ($resultado as $results) { // Insertar programadores en array --- //
                        array_push($resultadoF1, $results['Nombre']);
                    }

                    $restanteP = count($resultadoF1); // Actualizar contador de programadores --- //

                } else {
                    if ($categorias[$clave_aleatoriaT] == "modulos") {

                        $clave_aleatoria = array_rand($resultadoF2, 1); // Generar clave aleatoria--- //
                        $NombreC = $resultadoF2[$clave_aleatoria]; // seleccionar categoria al azar --- //

                        // Eliminar modulo de tabla programadores --- //
                        $sql = "DELETE FROM modulos$tablename WHERE modulos$tablename.Nombre = '$NombreC';"; 
                        $conexion->AdminT($sql);

                        // Actualizar lista de modulos --- //
                        $sql = "SELECT Nombre FROM modulos$tablename;";
                        $resultado = $conexion->Consulta($sql);
                        $resultadoF2 = [];

                        foreach ($resultado as $results) { // Insertar modulos en array --- //
                            array_push($resultadoF2, $results['Nombre']);
                        }

                        $restanteM = count($resultadoF2); // Actualizar contador de modulos --- //

                    } else {
                        $clave_aleatoria = array_rand($resultadoF3, 1); // Generar clave aleatoria--- //
                        $NombreC = $resultadoF3[$clave_aleatoria]; // seleccionar categoria al azar --- //

                        // Eliminar error de tabla programadores --- //
                        $sql = "DELETE FROM errores$tablename WHERE errores$tablename.Nombre = '$NombreC';";
                        $conexion->AdminT($sql);

                        // Actualizar lista de errores --- //
                        $sql = "SELECT Nombre FROM errores$tablename;";
                        $resultado = $conexion->Consulta($sql);
                        $resultadoF3 = [];

                        foreach ($resultado as $results) { // Insertar errores en array --- //
                            array_push($resultadoF3, $results['Nombre']);
                        }
                        $restanteE = count($resultadoF3); // Actualizar contador de errores --- //

                    }
                }

                // Insertar carta seleccionada en tabla secretos --- //
                $sql = "INSERT INTO cartas$tablename( IdCarta, NombreCarta, CategoriaCarta, IdJugador) VALUES( NULL, '$NombreC', '$Ccarta', $i);";
                $conexion->AdminT($sql);

                // Insertar carta seleccionada en tabla de jugador (N) --- //
                $sql = "INSERT INTO JugadorN$i$tablename( NCartas, NombreCarta, CategoriaCarta, IdJugador) VALUES( NULL, '$NombreC', '$Ccarta', $i);";
                $conexion->AdminT($sql);

            }

        }

        // Insertar enlace entre tabla de jugador 1 y tabla de jugadores --- //
        $sql = "ALTER TABLE JugadorN1$tablename ADD FOREIGN KEY(IdJugador) REFERENCES $tablename(JugadorId);";
        $conexion->AdminT($sql);
        
        // Eliminar tabla programadores --- //
        $sql = "DROP TABLE programadores$tablename;";
        $conexion->AdminT($sql);

        // Eliminar tabla modulos--- //
        $sql = "DROP TABLE modulos$tablename;";
        $conexion->AdminT($sql);

        // Eliminar tabla errores --- //
        $sql = "DROP TABLE errores$tablename;";
        $conexion->AdminT($sql);

        // Cerrar conexión con base de datos --- //
        $conexion->cerrar();

        return $tablename; // Codigo de partida --- //
    }

    // Insertar jugadores en partida(tabla) --- //
    static public function InsertarTablaP($nom, $codigo)
    {
        $tablename = "P".$codigo;

        // Abrir conexión con base de datos --- //
        $conexion = new Conexion();
        $conexion->abrir();

        // Insertar jugadores en partida(tabla) --- //
        $sql = "INSERT INTO $tablename( JugadorId, Nombre) VALUES( NULL, 'Jugador $nom');";
        $conexion->AdminT($sql);

        // Cerrar conexión con base de datos --- //
        $conexion->cerrar();
    }

    // Insertar relacion entre tablas --- //
    static public function InsertarLLaveF($Id, $codigo)
    {
        $tablename = "P".$codigo;

        // Abrir conexión con base de datos --- //
        $conexion = new Conexion();
        $conexion->abrir();

        // Insertar relacion entre tabla JugadorN y tabla de jugadores --- //
        $sql = "ALTER TABLE JugadorN$Id$codigo ADD FOREIGN KEY(IdJugador) REFERENCES $tablename(JugadorId);";
        $conexion->AdminT($sql);

        // Cerrar conexión con base de datos --- //
        $conexion->cerrar();
    }
}
