<?php

include_once 'modelo/conexion.php';

class ConsultarTabla
{

    // Buscar partida(tabla) --- //
    static public function ConsultarT($codigo)
    {
        // Abrir conexión con base de datos --- //
        $conexion = new Conexion();
        $conexion->abrir();

        // Realizar consulta --- //
        $tablename = "P".$codigo; //Codigo de partida --- //
        $sql = "SELECT JugadorId FROM $tablename;";
        $resultado = $conexion->Consulta($sql);

        // Cerrar conexión con base de datos --- //
        $conexion->cerrar();

        return count($resultado); // Resultado con cantidad total de registros --- //
    }   

    //Consultar cartas de cada jugador --- //
    static public function ConsultarCartas($Id, $codigo)
    {
        // Abrir conexión con base de datos --- //
        $conexion = new Conexion();
        $conexion->abrir();

        //Realizar consulta --- //
        $tablename = "P".$codigo; //Codigo de partida --- //
        $sql = "SELECT JugadorN$Id$codigo.*, $tablename.*  from JugadorN$Id$codigo, $tablename where JugadorN$Id$codigo.IdJugador = $tablename.JugadorId;";
        $resultado = $conexion->Consulta($sql);

        // Cerrar conexión con base de datos --- //
        $conexion->cerrar();

        return $resultado; // Array con las cartas --- //
    }
}
