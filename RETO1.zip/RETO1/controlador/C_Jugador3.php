<?php

require_once 'modelo/consultat.php';
require_once 'modelo/conexion.php';
require_once 'modelo/crearp.php';


error_reporting(0);

$Crear = new CrearPartida;
$Crear->InsertarTablaP($nom, $codigo);

$Crear = new CrearPartida;
$Crear->InsertarLLaveF(3, $codigo);


$nom = $_GET['nombre_jugador'];
$Consulta = new ConsultarTabla;
$Consulta = $Consulta->ConsultarCartas(3, $codigo);

require_once "vista/Jugador3.php";


?>