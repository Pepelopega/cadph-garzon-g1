<?php

include_once 'modelo/conexion.php';

class C_inicio{
    static public function Ver($ruta){
        require_once $ruta;
    }
}

?>