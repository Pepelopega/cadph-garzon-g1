<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>Welcome</title>
</head>

<body>
    <!-- Abrir container -->
    <div class="container-fluid">
        <!-- Abrir imagenes -->
        <div class="row">
            <div class="col-md-1">

            </div>

            <div class="col-md-4">
                <p class="text-center">
                <h1><br></h1>
                </p>
                <p class="text-center">
                <h1><br></h1>
                </p>
                <p class="text-center">
                <h1><br></h1>
                </p>
                <p class="text-center">
                <h1>ENCUENTRA EL BUG EN EL SISTEMA</h1>
                </p>

                <p class="text-center">
                <h1><br></h1>
                </p>
                <p class="text-center">
                <h3>Decifra quien y en donde han insertado el Bug.</h3>
                </p>
                <h1>Jugador
                    <?php
                    $Jugador = $_GET['nom_jug'];
                    echo $Jugador;

                    $Jugador2 = $_GET['nombre_jugador'];
                    echo $Jugador2;
                    ?>
                </h1>
            </div>

            <div class="col-md-2">
                <p class="text-center">
                <h1><br></h1>
                </p>
            </div>


            <div class="col-md-3">

                <p class="text-center">
                <h1><br></h1>
                </p>
                <p class="text-center">
                <h1><br></h1>
                </p>
                <p class="text-center">
                <h1><br></h1>
                </p>



                <!-- Abrir imagenes -->
                <div class="row">
                    <div class="col-md-12">
                        <img class="img-fluid" src="vista/img/siigo.jpg">
                    </div>
                </div>
                <br>

                <!-- Cerrar imagenes -->

            </div>

        </div>
        <br>


    </div>
    <!-- cerrar container -->
    <br>
    <br>

    <div class="row">

        <div class="col-md-1">
        </div>

        <div class="col-md-2">

            <form method="GET">
                <?php
                echo '<input type="hidden" name="nombre_jug" value="' . $Jugador . '" />';
                ?>

                <button type="sutmit" class="btn btn-primary btn-lg">CREAR PARTIDA</button>

            </form>

        </div>

        <div class="col-md-4">

            <form method="GET">

                <div class="input-group input-group-lg">
                    <span class="input-group-text"><i class="fas fa-keyboard"></i></span>
                    <input type="text" name="cod_partida" class="form-control" placeholder="Código de partida" aria-label="Código de partida">

                    <?php
                    echo '<input type="hidden" name="nombre_jugador" value="' . $Jugador . $Jugador2 . '" />';
                    ?>

                    <button type="sutmit" class="btn btn-primary btn-lg">UNIRSE</button>
                </div>

            </form>

        </div>

        <div class="col-md-5">
        </div>

    </div>




    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
</body>

</html>