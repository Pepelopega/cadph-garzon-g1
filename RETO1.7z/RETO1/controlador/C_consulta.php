<?php

require 'modelo/consultat.php';

class C_consultar{

    // Consular Tabla --- //
    static public function Cconsulta($codigo){

        $Consultar = new ConsultarTabla;
        $respuesta =  $Consultar->ConsultarT($codigo);

        return $respuesta;
    }

    // Consultar Cartas --- //
    static public function ConsultarC($Id, $codigo){

        $Consultar = new ConsultarTabla;
        $ResultadoCartas =  $Consultar->ConsultarCartas($Id, $codigo);

        return $ResultadoCartas;
    }
}

?>