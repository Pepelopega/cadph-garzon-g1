<?php

include_once 'modelo/unirp.php';

class UnirP{
    static public function BuscarP($codigo){
        $Buscar = new UnirsePartida;
        $respuesta =  $Buscar->BuscarPartida($codigo);

        return $respuesta;
    }
    
}

?>