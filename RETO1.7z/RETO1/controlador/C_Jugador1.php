<?php

require_once 'modelo/crearp.php';
require_once 'modelo/conexion.php';
require_once 'modelo/consultat.php';


error_reporting(0);

$Crear = new CrearPartida;

$nom = $_GET['nombre_jug'];
$codigo = $Crear->CrearTablaP($nom);
$Consulta = new ConsultarTabla;
$Consulta = $Consulta->ConsultarCartas(1, $codigo);


require_once "vista/Jugador1.php";


?>