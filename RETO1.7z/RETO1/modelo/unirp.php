<?php

include_once 'modelo/conexion.php';

class UnirsePartida
{

    // Buscar partida --- //
    static public function BuscarPartida($codigo)
    {
        $tablename = "P".$codigo;

        // Abrir conexión con base de datos --- //
        $conexion = new Conexion();
        $conexion->abrir();

        // Consultar si existen jugadores en partida(tabla) --- //
        $sql = "SELECT 1 FROM $tablename;";
        $valT = TRUE;
        $valF = FALSE;

        if ($conexion->BuscarT($sql) !== FALSE) {
            return $valT;
        } else {
            return $valF;
        }

        // Cerrar conexión con base de datos --- //
        $conexion->cerrar();
    }
}
